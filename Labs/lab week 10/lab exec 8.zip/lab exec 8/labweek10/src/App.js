import './App.css';
import Forms from './components/Forms';

function App() {
  return (
    <div className='App'>
      <h1>Data Entry Form</h1>
      <Forms />
    </div>
  );
}

export default App;
